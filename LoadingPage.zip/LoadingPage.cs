﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class LoadingPage : Form
    {
        public LoadingPage()
        {
            InitializeComponent();
        }
        int startpos = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
             startpos += 1;
           progressBar1 .Value = startpos;
           // label3.Text = startpos+"%";
            if (progressBar1.Value == 100)
            {
                progressBar1.Value = 0;
                timer1.Stop();
                Loginpage st = new Loginpage();
                st.Show();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            timer1.Start();
        }
    }
}
