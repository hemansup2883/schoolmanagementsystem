﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Loginpage : Form
    {
        public Loginpage()
        {
            InitializeComponent();
        }

        private void LOADING_Click(object sender, EventArgs e)
        {
            if (Unametb.Text == "" || pswtb.Text == "")
            {
                MessageBox.Show("Enter User Name And Passowd");
            }
            else if (Unametb.Text == "hemansu" && pswtb.Text == "Admin")
            {
                
                MainManuPage     obj = new MainManuPage();
                obj.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Wrong UserName And Password");
                Unametb.Text = "";
                pswtb.Text = "";

            }
        }
    }
}
